export type FilterType = "all" | "offline" | "unity-down" | "low-battery" | "wrong-version"

export interface Device {
  id: string
  alias: string
  status: "online" | "offline"
  lastSeen: string
  battery: {
    percentage: number
    charging: boolean
  }
  network: {
    type: "wifi" | "cellular"
    name: string
  }
  unity: {
    version: string
    status: "running" | "down"
  }
  ram: number
  uptime: string
}

export const mockDevices: Device[] = [
  {
    id: "1",
    alias: "Warehouse-A-01",
    status: "online",
    lastSeen: "2m ago",
    battery: { percentage: 87, charging: false },
    network: { type: "wifi", name: "Warehouse-5G" },
    unity: { version: "1.2.3", status: "running" },
    ram: 42,
    uptime: "3d 12h",
  },
  {
    id: "2",
    alias: "Warehouse-A-02",
    status: "online",
    lastSeen: "5m ago",
    battery: { percentage: 65, charging: true },
    network: { type: "wifi", name: "Warehouse-5G" },
    unity: { version: "1.2.3", status: "running" },
    ram: 38,
    uptime: "2d 8h",
  },
  {
    id: "3",
    alias: "Warehouse-B-01",
    status: "offline",
    lastSeen: "2h ago",
    battery: { percentage: 12, charging: false },
    network: { type: "wifi", name: "Warehouse-5G" },
    unity: { version: "1.2.2", status: "down" },
    ram: 78,
    uptime: "1d 4h",
  },
  {
    id: "4",
    alias: "Warehouse-B-02",
    status: "online",
    lastSeen: "1m ago",
    battery: { percentage: 94, charging: false },
    network: { type: "cellular", name: "Verizon" },
    unity: { version: "1.2.3", status: "running" },
    ram: 35,
    uptime: "5d 2h",
  },
  {
    id: "5",
    alias: "Warehouse-C-01",
    status: "online",
    lastSeen: "3m ago",
    battery: { percentage: 56, charging: false },
    network: { type: "wifi", name: "Warehouse-5G" },
    unity: { version: "1.2.3", status: "running" },
    ram: 45,
    uptime: "4d 18h",
  },
  {
    id: "6",
    alias: "Warehouse-C-02",
    status: "online",
    lastSeen: "8m ago",
    battery: { percentage: 73, charging: true },
    network: { type: "wifi", name: "Warehouse-5G" },
    unity: { version: "1.2.3", status: "running" },
    ram: 41,
    uptime: "6d 5h",
  },
  {
    id: "7",
    alias: "Warehouse-D-01",
    status: "offline",
    lastSeen: "45m ago",
    battery: { percentage: 8, charging: false },
    network: { type: "wifi", name: "Warehouse-5G" },
    unity: { version: "1.2.1", status: "down" },
    ram: 82,
    uptime: "12h",
  },
  {
    id: "8",
    alias: "Warehouse-D-02",
    status: "online",
    lastSeen: "4m ago",
    battery: { percentage: 91, charging: false },
    network: { type: "wifi", name: "Warehouse-5G" },
    unity: { version: "1.2.3", status: "running" },
    ram: 39,
    uptime: "7d 14h",
  },
]
