"use client"

import { Battery, Wifi, Smartphone } from "lucide-react"
import type { Device } from "@/lib/mock-data"
import { Button } from "@/components/ui/button"

interface DevicesTableProps {
  devices: Device[]
  onSelectDevice: (device: Device) => void
}

export function DevicesTable({ devices, onSelectDevice }: DevicesTableProps) {
  if (devices.length === 0) {
    return (
      <div className="rounded-xl border-2 border-dashed border-border bg-card p-12 text-center">
        <Smartphone className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
        <h3 className="mb-2 text-lg font-semibold">No devices enrolled yet</h3>
        <p className="mb-6 text-sm text-muted-foreground">Get started by enrolling your first device</p>
        <Button>Open Settings</Button>
      </div>
    )
  }

  return (
    <div className="overflow-hidden rounded-xl bg-card shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="sticky top-[132px] z-30 border-b border-border bg-muted/50 backdrop-blur-xl">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
              <th className="px-4 py-3 text-left text-sm font-medium">Alias</th>
              <th className="px-4 py-3 text-left text-sm font-medium">Last Seen</th>
              <th className="px-4 py-3 text-right text-sm font-medium">Battery</th>
              <th className="px-4 py-3 text-left text-sm font-medium">Network</th>
              <th className="px-4 py-3 text-left text-sm font-medium">Unity</th>
              <th className="hidden px-4 py-3 text-right text-sm font-medium md:table-cell">RAM</th>
              <th className="px-4 py-3 text-right text-sm font-medium">Uptime</th>
            </tr>
          </thead>
          <tbody>
            {devices.map((device, index) => (
              <tr
                key={device.id}
                onClick={() => onSelectDevice(device)}
                className={`cursor-pointer transition-colors hover:bg-muted/30 ${
                  index % 2 === 0 ? "bg-background" : "bg-muted/10"
                }`}
              >
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div
                      className={`h-2 w-2 rounded-full ${
                        device.status === "online" ? "bg-status-online" : "bg-status-offline"
                      }`}
                    />
                    <span className="text-sm capitalize">{device.status}</span>
                  </div>
                </td>
                <td className="px-4 py-3 text-sm font-medium">{device.alias}</td>
                <td className="px-4 py-3 text-sm text-muted-foreground">{device.lastSeen}</td>
                <td className="px-4 py-3 text-right">
                  <div className="flex items-center justify-end gap-1.5">
                    <span className={`text-sm ${device.battery.percentage < 20 ? "text-status-offline" : ""}`}>
                      {device.battery.percentage}%
                    </span>
                    {device.battery.charging && <Battery className="h-3.5 w-3.5 text-status-online" />}
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1.5">
                    <Wifi className="h-3.5 w-3.5 text-muted-foreground" />
                    <span className="text-sm">{device.network.name}</span>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{device.unity.version}</span>
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs ${
                        device.unity.status === "running"
                          ? "bg-status-online/10 text-status-online"
                          : "bg-status-offline/10 text-status-offline"
                      }`}
                    >
                      {device.unity.status}
                    </span>
                  </div>
                </td>
                <td className="hidden px-4 py-3 text-right text-sm md:table-cell">{device.ram}%</td>
                <td className="px-4 py-3 text-right text-sm text-muted-foreground">{device.uptime}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
