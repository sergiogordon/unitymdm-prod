"use client"

import { useEffect, useState } from "react"
import { X, Copy, Check } from "lucide-react"
import { Button } from "@/components/ui/button"

interface SettingsDrawerProps {
  isOpen: boolean
  onClose: () => void
}

export function SettingsDrawer({ isOpen, onClose }: SettingsDrawerProps) {
  const [lastTestAlert, setLastTestAlert] = useState<string | null>(null)
  const [copiedItem, setCopiedItem] = useState<string | null>(null)

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
    }
    if (isOpen) {
      document.addEventListener("keydown", handleEscape)
      document.body.style.overflow = "hidden"
    }
    return () => {
      document.removeEventListener("keydown", handleEscape)
      document.body.style.overflow = "unset"
    }
  }, [isOpen, onClose])

  const handleSendTestAlert = () => {
    setLastTestAlert(new Date().toLocaleString())
  }

  const handleCopy = (text: string, item: string) => {
    navigator.clipboard.writeText(text)
    setCopiedItem(item)
    setTimeout(() => setCopiedItem(null), 2000)
  }

  if (!isOpen) return null

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/20 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed right-0 top-0 z-50 h-full w-full max-w-[480px] animate-in slide-in-from-right">
        <div className="flex h-full flex-col bg-card shadow-2xl">
          <div className="flex items-center justify-between border-b border-border px-6 py-4">
            <h2 className="text-lg font-semibold">Settings</h2>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            {/* Display Preferences */}
            <section className="mb-8">
              <h3 className="mb-4 text-sm font-semibold">Display Preferences</h3>
              <div className="space-y-4">
                <div>
                  <label className="mb-2 block text-sm text-muted-foreground">Refresh Interval</label>
                  <select className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm">
                    <option>30 seconds</option>
                    <option>1 minute</option>
                    <option>5 minutes</option>
                  </select>
                </div>
                <div className="flex items-center justify-between">
                  <label className="text-sm text-muted-foreground">Compact rows</label>
                  <button className="relative h-6 w-11 rounded-full bg-muted transition-colors hover:bg-muted/80">
                    <span className="absolute left-1 top-1 h-4 w-4 rounded-full bg-background transition-transform" />
                  </button>
                </div>
              </div>
            </section>

            {/* Discord */}
            <section className="mb-8">
              <h3 className="mb-4 text-sm font-semibold">Discord</h3>
              <div className="space-y-3">
                <Button onClick={handleSendTestAlert} className="w-full">
                  Send Test Alert
                </Button>
                {lastTestAlert && <p className="text-xs text-muted-foreground">Last test: {lastTestAlert}</p>}
              </div>
            </section>

            {/* Enrollment */}
            <section className="mb-8">
              <h3 className="mb-4 text-sm font-semibold">Enrollment</h3>
              <p className="mb-4 text-sm text-muted-foreground">
                Use these commands to enroll devices in Unity Micro-MDM.
              </p>

              <div className="mb-4 space-y-3">
                <Button
                  variant="outline"
                  className="w-full justify-between bg-transparent"
                  onClick={() => handleCopy("curl -s https://example.com/enroll.sh | bash", "single")}
                >
                  <span>Copy single-device command</span>
                  {copiedItem === "single" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>

                <Button
                  variant="outline"
                  className="w-full justify-between bg-transparent"
                  onClick={() => handleCopy("# Bulk enrollment template...", "bulk")}
                >
                  <span>Copy bulk template</span>
                  {copiedItem === "bulk" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>

              <div className="rounded-lg bg-muted p-3">
                <p className="mb-2 text-xs font-medium">SERVER_URL</p>
                <code className="text-xs text-muted-foreground">https://mdm.example.com</code>
              </div>

              <p className="mt-3 text-xs text-muted-foreground">
                Remember to set your ADMIN_KEY environment variable before enrolling devices.
              </p>
            </section>

            {/* Android Permissions */}
            <section>
              <h3 className="mb-4 text-sm font-semibold">Android Permissions</h3>
              <ol className="space-y-2 text-sm text-muted-foreground">
                <li>1. Open Settings → Apps → Unity MDM</li>
                <li>2. Enable "Display over other apps"</li>
                <li>3. Enable "Modify system settings"</li>
                <li>4. Grant location permissions</li>
                <li>5. Enable battery optimization exemption</li>
              </ol>
            </section>
          </div>
        </div>
      </div>
    </>
  )
}
