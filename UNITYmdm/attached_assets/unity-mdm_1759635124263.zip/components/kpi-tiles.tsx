interface KpiTilesProps {
  total: number
  online: number
  offline: number
  alerts: number
}

export function KpiTiles({ total, online, offline, alerts }: KpiTilesProps) {
  return (
    <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <div className="rounded-xl bg-card p-6 shadow-sm">
        <div className="text-3xl font-semibold tracking-tight">{total}</div>
        <div className="mt-1 text-sm text-muted-foreground">Total Devices</div>
      </div>

      <div className="rounded-xl bg-card p-6 shadow-sm">
        <div className="text-3xl font-semibold tracking-tight text-status-online">{online}</div>
        <div className="mt-1 text-sm text-muted-foreground">Online</div>
      </div>

      <div className="rounded-xl bg-card p-6 shadow-sm">
        <div className={`text-3xl font-semibold tracking-tight ${offline > 0 ? "text-status-offline" : ""}`}>
          {offline}
        </div>
        <div className="mt-1 text-sm text-muted-foreground">Offline</div>
      </div>

      <div className="rounded-xl bg-card p-6 shadow-sm">
        <div className={`text-3xl font-semibold tracking-tight ${alerts > 0 ? "text-status-warning" : ""}`}>
          {alerts}
        </div>
        <div className="mt-1 text-sm text-muted-foreground">Active Alerts</div>
      </div>
    </div>
  )
}
